package com.beefe.picker.view;

import java.util.ArrayList;

/**
 * Created by heng on 16/9/6.
 */

public interface OnSelectedListener {

    void onSelected(ArrayList<ReturnData> selectedList);

}
